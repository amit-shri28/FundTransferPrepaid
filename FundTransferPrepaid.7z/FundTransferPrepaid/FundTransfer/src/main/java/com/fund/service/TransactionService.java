package com.fund.service;

import com.fund.dto.TransactionRequest;
import com.fund.model.Child;
import com.fund.model.Parent;
import com.fund.model.PrepaidCard;
import com.fund.repository.ChildRepository;
import com.fund.repository.ParentRepository;
import com.fund.repository.PrepaidCardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Optional;
import java.util.regex.Pattern;

public class TransactionService {

    private static final String ACCOUNT_NUMBER_PATTERN = "^[0-9]{10}$";

    @Autowired
    private ParentRepository parentRepository;

    @Autowired
    private ChildRepository childRepository;
    @Autowired
    private PrepaidCardRepository prepaidCardRepository;

    public void loadFundsToChild(TransactionRequest transactionRequest){
        String childAccountNumber = transactionRequest.childActNumber();
        double amount = transactionRequest.amount();

        UserDetails currentUserDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String parentUserName = currentUserDetails.getUsername();

        Parent parent = parentRepository.findByUsername(parentUserName).orElseThrow(() -> new RuntimeException("Parent Not Found"));

        Optional<Child> childOpt = childRepository.findByAccountNumber(childAccountNumber);
        if(!childOpt.isPresent()){
            throw new RuntimeException("child account number is not valid");

        }

        Child child = childOpt.get();
        if(child.getParent() == null || !child.getParent().equals(parent)){
            throw new RuntimeException("Only the Parent can load funds into child's prepaid account");
        }

        if(!Pattern.matches(ACCOUNT_NUMBER_PATTERN, childAccountNumber)){
            throw new RuntimeException("Invalid receiver or child account number");
        }

        PrepaidCard prepaidCard = prepaidCardRepository.findByChild(child).orElseThrow(() -> new RuntimeException("Prepaid card not found"));
        prepaidCard.setBalance(prepaidCard.getBalance() + amount);
        prepaidCardRepository.save(prepaidCard);

    }

}
