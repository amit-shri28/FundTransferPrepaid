package com.fund.repository;


import com.fund.model.Child;
import com.fund.model.PrepaidCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface PrepaidCardRepository extends JpaRepository<PrepaidCard,Long> {
    Optional<PrepaidCard> findByChild(Child child);
}
