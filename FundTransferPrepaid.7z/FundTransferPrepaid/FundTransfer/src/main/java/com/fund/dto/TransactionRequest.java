package com.fund.dto;

public record TransactionRequest(String childActNumber, double amount) {

}
