package com.fund.controller;

import com.fund.dto.TransactionRequest;
import com.fund.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @PostMapping("/load-funds")
    public ResponseEntity<String> loadFunds(@RequestBody TransactionRequest txnReq){
        try{
            transactionService.loadFundsToChild(txnReq);
            return ResponseEntity.ok("Funds loaded successfully");
        } catch(Exception ex){
            return ResponseEntity.status(400).body("Error : " +ex.getMessage());
        }
    }
}
