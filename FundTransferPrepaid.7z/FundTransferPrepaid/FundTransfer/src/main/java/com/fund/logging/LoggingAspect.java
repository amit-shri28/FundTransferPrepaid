package com.fund.logging;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.fund.dto.TransactionRequest;

@Aspect
@Component
public class LoggingAspect {

    @Before("execution(* com.fund.service.TransactionService.loadFundsToChild(..)) && args(txnReq)")
    public void logBeforeTxn(TransactionRequest txnReq){
        System.out.println("Attempting to load funds into child's prepaid card acct No" + txnReq.childActNumber() + "amount" +txnReq.amount());
    }

    @AfterReturning("execution(* com.fund.service.TransactionService.loadFundsToChild(..))")
    public void logAfterTxn(TransactionRequest txnReq){
        System.out.println("load funded successfully into child's prepaid card");
    }

    @AfterThrowing(pointcut = "execution(* com.fund.service.TransactionService.loadFundsToChild(..))", throwing = "ex")
    public void logException(Exception ex){
        System.out.println("Error while loading funds : " + ex.getMessage());
    }
}
