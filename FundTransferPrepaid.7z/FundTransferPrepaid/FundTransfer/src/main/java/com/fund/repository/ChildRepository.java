package com.fund.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.fund.model.Child;

@EnableJpaRepositories
public interface ChildRepository extends JpaRepository<Child,Long> {
    Optional<Child> findByAccountNumber(String accountNumber);
}
