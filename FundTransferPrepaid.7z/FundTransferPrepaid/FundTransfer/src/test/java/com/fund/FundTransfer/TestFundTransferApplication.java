package com.fund.FundTransfer;

import org.springframework.boot.SpringApplication;

public class TestFundTransferApplication {

	public static void main(String[] args) {
		SpringApplication.from(FundTransferApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
