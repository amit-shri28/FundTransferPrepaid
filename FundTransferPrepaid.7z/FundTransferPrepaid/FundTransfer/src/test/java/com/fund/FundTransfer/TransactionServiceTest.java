package com.fund.FundTransfer;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class TransactionServiceTest{

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testLoadFunds() throws Exception {
        mockMvc.perform(post("/transactions/load-funds")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"childAccountNumber\": \"1234567890\", \"amount\":5000}"))
                .andExpect(status().isOk());
                //.andExpect(content().string("Funds loaded Successfully"));
    }

    @Test
    public void testInvalidAccountNoFormat() throws Exception {
        mockMvc.perform(post("/transactions/load-funds")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"childAccountNumber\": \"1234\", \"amount\":5000}"))
                .andExpect(status().isBadRequest());
                //.andExpect((content().toString("Error: Account Number format is not valid")));
    }

    @Test
    public void testAuthorizedParent() throws Exception {
        mockMvc.perform(post("/transactions/load-funds")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"childAccountNumber\": \"1234567890\", \"amount\":5000}"))
                .andExpect(status().isForbidden());

    }


}
